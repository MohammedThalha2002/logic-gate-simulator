import React, { useState } from "react";

function LogicGate() {
  return (
    <div>
      <ANDGate />
      <ORGate />
    </div>
  );
}

function ORGate() {
  const [in1, setIn1] = useState(false);
  const [in2, setIn2] = useState(false);

  return (
    <svg
      width={234}
      height={85}
      viewBox="0 0 234 85"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g id="OR GATE">
        <g id="OUT">
          <line
            id="out"
            x1="184.726"
            y1="41.8529"
            x2="224.483"
            y2="41.8529"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-out"
            cx="228.459"
            cy="41.8529"
            r="4.33714"
            fill={in1 || in2 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="IN-2" onClick={() => setIn2(!in2)}>
          <line
            id="IN_2"
            x1="10.5171"
            y1="64.9843"
            x2="52.4428"
            y2="64.9843"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-in-2"
            cx="5.8184"
            cy="64.9843"
            r="4.33714"
            fill={in2 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="IN-1" onClick={() => setIn1(!in1)}>
          <line
            id="IN_1"
            x1="10.5171"
            y1="19.4443"
            x2="52.4428"
            y2="19.4443"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-in-1"
            cx="5.8184"
            cy="19.4443"
            r="4.33714"
            fill={in1 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="BODY">
          <path
            id="frame"
            d="M54.9729 2.81857H147.86C169.618 2.81857 187.256 20.4566 187.256 42.2143C187.256 63.9719 169.618 81.61 147.86 81.61H54.9729V2.81857Z"
            stroke="black"
            strokeWidth="5.06"
          />
          <text
            id="Text"
            fill="black"
            xmlSpace="preserve"
            style={{ whiteSpace: "pre" }}
            fontFamily="Inter"
            fontSize="23.1314"
            fontWeight="bold"
            letterSpacing="0em"
          >
            <tspan x="93.6455" y="50.8914">
              OR
            </tspan>
          </text>
        </g>
      </g>
    </svg>
  );
}

function ANDGate() {
  const [in1, setIn1] = useState(false);
  const [in2, setIn2] = useState(false);

  return (
    <svg
      width={234}
      height={85}
      viewBox="0 0 234 85"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g id="AND GATE">
        <g id="OUT">
          <line
            id="out"
            x1="184.726"
            y1="41.8529"
            x2="224.483"
            y2="41.8529"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-out"
            cx="228.459"
            cy="41.8529"
            r="4.33714"
            fill={in1 && in2 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="IN-2" onClick={() => setIn2(!in2)}>
          <line
            id="IN_2"
            x1="10.5171"
            y1="64.9843"
            x2="52.4428"
            y2="64.9843"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-in-2"
            cx="5.8184"
            cy="64.9843"
            r="4.33714"
            fill={in2 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="IN-1" onClick={() => setIn1(!in1)}>
          <line
            id="IN_1"
            x1="10.5171"
            y1="19.4443"
            x2="52.4428"
            y2="19.4443"
            stroke="black"
            strokeWidth="5.06"
          />
          <circle
            id="point-in-1"
            cx="5.8184"
            cy="19.4443"
            r="4.33714"
            fill={in1 ? "#FF0000" : "#FFFFF"}
            stroke="black"
            strokeWidth="2.16857"
          />
        </g>
        <g id="BODY">
          <path
            id="frame"
            d="M54.9729 2.81857H147.86C169.618 2.81857 187.256 20.4566 187.256 42.2143C187.256 63.9719 169.618 81.61 147.86 81.61H54.9729V2.81857Z"
            stroke="black"
            strokeWidth="5.06"
          />
          <text
            id="Text"
            fill="black"
            xmlSpace="preserve"
            style={{ whiteSpace: "pre" }}
            fontFamily="Inter"
            fontSize="23.1314"
            fontWeight="bold"
            letterSpacing="0em"
          >
            <tspan x="93.6455" y="50.8914">
              AND
            </tspan>
          </text>
        </g>
      </g>
    </svg>
  );
}

export default LogicGate;
